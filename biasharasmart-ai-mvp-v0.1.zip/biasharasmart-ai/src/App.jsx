import { useMemo, useState } from "react";
import {
  LayoutDashboard, Users, Package, ShoppingBag, FileText, Sparkles,
  Settings, Search, Bell, Plus, ArrowUpRight, Menu, X, TrendingUp,
  Clock3, CircleCheck, MoreHorizontal, Send, Download, ChevronDown
} from "lucide-react";

const initialCustomers = [
  { id: 1, name: "Amina Hassan", contact: "+255 712 000 111", orders: 5, status: "Active" },
  { id: 2, name: "John Michael", contact: "+255 754 000 222", orders: 3, status: "Active" },
  { id: 3, name: "Neema Peter", contact: "+255 687 000 333", orders: 2, status: "New" },
];
const initialProducts = [
  { id: 1, name: "Kikapu cha zawadi", sku: "PRD-001", price: 45000, stock: 18 },
  { id: 2, name: "T-shirt ya Biashara", sku: "PRD-002", price: 25000, stock: 32 },
  { id: 3, name: "Huduma ya delivery", sku: "SRV-003", price: 5000, stock: 999 },
];
const initialOrders = [
  { id: "BS-1004", customer: "Amina Hassan", item: "Kikapu cha zawadi", amount: 45000, status: "Imekamilika", date: "Leo" },
  { id: "BS-1003", customer: "John Michael", item: "T-shirt ya Biashara", amount: 50000, status: "Inaendelea", date: "Leo" },
  { id: "BS-1002", customer: "Neema Peter", item: "Huduma ya delivery", amount: 5000, status: "Inasubiri", date: "Jana" },
];

const money = n => new Intl.NumberFormat("sw-TZ", { style: "currency", currency: "TZS", maximumFractionDigits: 0 }).format(n);

function App() {
  const [page, setPage] = useState("Muhtasari");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [customers, setCustomers] = useState(initialCustomers);
  const [products, setProducts] = useState(initialProducts);
  const [orders, setOrders] = useState(initialOrders);
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: "", contact: "", price: "", stock: "" });
  const [notice, setNotice] = useState("");
  const [prompt, setPrompt] = useState("");
  const [generated, setGenerated] = useState("");

  const nav = [
    { label: "Muhtasari", icon: LayoutDashboard },
    { label: "Wateja", icon: Users },
    { label: "Bidhaa", icon: Package },
    { label: "Oda", icon: ShoppingBag },
    { label: "Invoices", icon: FileText },
    { label: "AI Msaidizi", icon: Sparkles },
  ];

  const totalSales = orders.filter(o => o.status === "Imekamilika").reduce((s, o) => s + o.amount, 0);
  const filteredCustomers = useMemo(() => customers.filter(c =>
    `${c.name} ${c.contact}`.toLowerCase().includes(search.toLowerCase())
  ), [customers, search]);

  function addRecord(e) {
    e.preventDefault();
    if (page === "Wateja") {
      if (!form.name.trim() || !form.contact.trim()) return;
      setCustomers([...customers, { id: Date.now(), name: form.name, contact: form.contact, orders: 0, status: "New" }]);
      setNotice("Mteja ameongezwa kwenye orodha.");
    } else if (page === "Bidhaa") {
      if (!form.name.trim() || !form.price) return;
      setProducts([...products, { id: Date.now(), name: form.name, sku: `PRD-${String(products.length + 1).padStart(3,"0")}`, price: Number(form.price), stock: Number(form.stock || 0) }]);
      setNotice("Bidhaa imeongezwa kwenye orodha.");
    }
    setForm({ name: "", contact: "", price: "", stock: "" });
    setShowAdd(false);
    setTimeout(() => setNotice(""), 3000);
  }

  function makeDraft() {
    if (!prompt.trim()) return;
    setGenerated(`Habari! Karibu ${prompt}. Tunakushukuru kwa kutufuatilia. Tuna bidhaa na huduma zenye ubora na tunafurahi kukuhudumia. Wasiliana nasi ili upate maelezo zaidi na bei. Asante kwa kuchagua biashara yetu!`);
  }

  const title = page;
  const subtitle = {
    "Muhtasari": "Karibu tena! Huu hapa muhtasari wa biashara yako.",
    "Wateja": "Hifadhi na fuatilia taarifa za wateja wako.",
    "Bidhaa": "Simamia bidhaa, huduma, bei na stock.",
    "Oda": "Fuatilia oda na hali ya utekelezaji wake.",
    "Invoices": "Tengeneza na fuatilia ankara za wateja.",
    "AI Msaidizi": "Andaa rasimu za matangazo na majibu kwa msaada wa AI."
  }[page];

  function go(label) { setPage(label); setMobileOpen(false); setSearch(""); }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
      <div className="brand">
        <div className="brand-mark">B</div>
        <div><strong>BiasharaSmart</strong><span>AI BUSINESS SUITE</span></div>
        <button className="icon-btn close-menu" onClick={() => setMobileOpen(false)}><X size={19}/></button>
      </div>
      <div className="workspace"><div className="workspace-avatar">BS</div><div><b>Biashara yangu</b><small>Mpango wa majaribio</small></div><ChevronDown size={16}/></div>
      <p className="nav-caption">MENU KUU</p>
      <nav>{nav.map(({label, icon: Icon}) =>
        <button key={label} className={`nav-item ${page === label ? "active" : ""}`} onClick={() => go(label)}>
          <Icon size={18}/><span>{label}</span>{label === "AI Msaidizi" && <i>NEW</i>}
        </button>
      )}</nav>
      <div className="sidebar-bottom">
        <button className="nav-item" onClick={() => setNotice("Mipangilio itapatikana kwenye toleo lijalo.")}><Settings size={18}/>Mipangilio</button>
        <div className="help-card"><Sparkles size={18}/><b>Unahitaji msaada?</b><p>Jifunze kutumia BiasharaSmart AI.</p><button onClick={() => go("AI Msaidizi")}>Jaribu msaidizi <ArrowUpRight size={14}/></button></div>
        <div className="profile"><div className="avatar">AN</div><div><b>Mmiliki wa biashara</b><small>Administrator</small></div><MoreHorizontal size={18}/></div>
      </div>
    </aside>

    {mobileOpen && <button className="scrim" aria-label="Funga menyu" onClick={() => setMobileOpen(false)}/>}

    <main className="main">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)}><Menu/></button>
        <div className="breadcrumb">Biashara yangu <span>/</span> <b>{page}</b></div>
        <div className="top-actions">
          <div className="searchbox"><Search size={17}/><input placeholder="Tafuta..." value={search} onChange={e => setSearch(e.target.value)}/><kbd>⌘ K</kbd></div>
          <button className="icon-btn notification" aria-label="Arifa"><Bell size={19}/><i/></button>
          <div className="avatar top-avatar">AN</div>
        </div>
      </header>

      <section className="content">
        <div className="page-heading">
          <div><p className="eyebrow">DASHBOARD</p><h1>{title}</h1><p className="muted">{subtitle}</p></div>
          {["Wateja","Bidhaa"].includes(page) && <button className="primary-btn" onClick={() => setShowAdd(true)}><Plus size={17}/> Ongeza {page === "Wateja" ? "mteja" : "bidhaa"}</button>}
        </div>

        {notice && <div className="notice"><CircleCheck size={17}/>{notice}</div>}

        {page === "Muhtasari" && <>
          <div className="welcome-banner"><div><span className="banner-pill"><Sparkles size={13}/> MUHTASARI WA BIASHARA</span><h2>Simamia biashara yako<br/>kwa <em>akili zaidi.</em></h2><p>Anza kwa kurekodi wateja, bidhaa na oda zako.</p><button onClick={() => go("Wateja")}>Anza kusimamia <ArrowUpRight size={16}/></button></div><div className="banner-art"><div className="art-circle"><TrendingUp size={56}/></div><div className="float-card"><small>Mauzo yaliyorekodiwa</small><b>{money(totalSales)}</b><span><ArrowUpRight size={13}/> Data ya mfano</span></div></div></div>
          <div className="section-title"><div><h3>Muhtasari wa leo</h3><p>Hali ya biashara yako kwa sasa</p></div><button className="select-btn">Muda wote <ChevronDown size={15}/></button></div>
          <div className="stats-grid">
            <Stat icon={Users} label="Wateja" value={customers.length} note="Wateja waliosajiliwa"/>
            <Stat icon={ShoppingBag} label="Oda" value={orders.length} note="Oda zilizorekodiwa"/>
            <Stat icon={TrendingUp} label="Mauzo yaliyokamilika" value={money(totalSales)} note="Kutokana na data ya mfano"/>
            <Stat icon={Package} label="Bidhaa / huduma" value={products.length} note="Vilivyopo kwenye katalogi"/>
          </div>
          <div className="dashboard-grid">
            <div className="panel"><div className="panel-head"><div><h3>Oda za hivi karibuni</h3><p>Oda za mwisho zilizorekodiwa</p></div><button className="text-btn" onClick={() => go("Oda")}>Tazama zote <ArrowUpRight size={14}/></button></div><OrdersTable orders={orders.slice(0,4)}/></div>
            <div className="panel quick-panel"><div className="panel-head"><div><h3>Vitendo vya haraka</h3><p>Fanya kazi kwa haraka</p></div></div><Quick label="Ongeza mteja" desc="Sajili mteja mpya" icon={Users} onClick={() => go("Wateja")}/><Quick label="Ongeza bidhaa" desc="Sasisha katalogi yako" icon={Package} onClick={() => go("Bidhaa")}/><Quick label="Andaa tangazo" desc="Tumia AI msaidizi" icon={Sparkles} onClick={() => go("AI Msaidizi")}/></div>
          </div>
          <p className="demo-note"><i/> Hii ni MVP ya majaribio. Namba zinazoonekana ni data za mfano, si mapato halisi.</p>
        </>}

        {page === "Wateja" && <div className="panel"><div className="panel-head"><div><h3>Orodha ya wateja</h3><p>{customers.length} wateja waliosajiliwa kwenye kifaa hiki</p></div><span className="soft-tag">CRM</span></div><div className="table-wrap"><table><thead><tr><th>JINA</th><th>MAWASILIANO</th><th>ODA</th><th>HALI</th></tr></thead><tbody>{filteredCustomers.map(c=><tr key={c.id}><td><b>{c.name}</b></td><td>{c.contact}</td><td>{c.orders}</td><td><Status value={c.status}/></td></tr>)}</tbody></table>{filteredCustomers.length===0 && <p className="empty">Hakuna mteja anayelingana na utafutaji.</p>}</div></div>}

        {page === "Bidhaa" && <div className="panel"><div className="panel-head"><div><h3>Bidhaa na huduma</h3><p>{products.length} bidhaa/huduma kwenye katalogi</p></div><span className="soft-tag">CATALOG</span></div><div className="table-wrap"><table><thead><tr><th>BIDHAA / HUDUMA</th><th>SKU</th><th>BEI</th><th>STOCK</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td><b>{p.name}</b></td><td>{p.sku}</td><td>{money(p.price)}</td><td>{p.stock}</td></tr>)}</tbody></table></div></div>}

        {page === "Oda" && <div className="panel"><div className="panel-head"><div><h3>Oda zote</h3><p>Fuatilia hatua ya kila oda</p></div><span className="soft-tag">{orders.length} ODA</span></div><OrdersTable orders={orders}/></div>}

        {page === "Invoices" && <div className="panel empty-panel"><div className="empty-icon"><FileText size={28}/></div><h3>Invoices zinakuja</h3><p>Katika hatua inayofuata tutaunganisha oda na mfumo wa kutengeneza PDF invoices zenye namba za kipekee.</p><button className="primary-btn" onClick={() => go("Oda")}>Angalia oda <ArrowUpRight size={16}/></button></div>}

        {page === "AI Msaidizi" && <div className="ai-layout"><div className="panel ai-panel"><div className="ai-title"><div className="ai-icon"><Sparkles/></div><div><h3>AI Marketing Assistant</h3><p>Rasimu ya maandishi ya biashara yako</p></div><span className="soft-tag">DEMO</span></div><label className="field-label">Eleza bidhaa au huduma unayotaka kutangaza</label><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Mfano: Ninauza viatu vya michezo kwa vijana, bei kuanzia TSh 35,000..." rows="5"/><button className="primary-btn" onClick={makeDraft}><Sparkles size={17}/> Tengeneza rasimu</button><p className="demo-note"><i/> Hii ni demo ya template; bado haijaunganishwa na AI API.</p></div>{generated && <div className="panel"><div className="panel-head"><div><h3>Rasimu yako</h3><p>Isome na uibadilishe kabla ya kuitumia.</p></div><button className="icon-btn" onClick={()=>navigator.clipboard?.writeText(generated)} title="Copy"><Download size={17}/></button></div><div className="generated-text">{generated}</div><button className="secondary-btn" onClick={()=>setGenerated("")}>Futa rasimu</button></div>}</div>}
      </section>
      <footer>© 2026 BiasharaSmart AI <span>Prototype v0.1 · Imetengenezwa kwa ajili ya majaribio</span></footer>
    </main>

    {showAdd && <div className="modal-backdrop" onClick={()=>setShowAdd(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><h3>Ongeza {page === "Wateja" ? "mteja" : "bidhaa"}</h3><p>Jaza taarifa zilizo hapa chini.</p></div><button className="icon-btn" onClick={()=>setShowAdd(false)}><X/></button></div><form onSubmit={addRecord}><label className="field-label">{page === "Wateja" ? "Jina la mteja" : "Jina la bidhaa / huduma"}</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Andika jina..."/>{page === "Wateja" ? <><label className="field-label">Namba ya simu</label><input required value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} placeholder="+255..."/></> : <><label className="field-label">Bei (TZS)</label><input required type="number" min="0" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="Mfano 25000"/><label className="field-label">Stock</label><input type="number" min="0" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})} placeholder="Mfano 10"/></>}<button className="primary-btn full-btn" type="submit"><Plus size={17}/> Hifadhi</button></form></div></div>}
  </div>;
}

function Stat({icon:Icon,label,value,note}) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><div><Icon size={18}/></div></div><strong>{value}</strong><small>{note}</small></div>; }
function Status({value}) { const cls = value==="Imekamilika" || value==="Active" ? "green" : value==="Inaendelea" ? "blue" : "amber"; return <span className={`status ${cls}`}><i/>{value}</span>; }
function OrdersTable({orders}) { return <div className="table-wrap"><table><thead><tr><th>ODA</th><th>MTEJA</th><th>HUDUMA / BIDHAA</th><th>JUMLA</th><th>HALI</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td><b>{o.id}</b><small className="cell-sub">{o.date}</small></td><td>{o.customer}</td><td>{o.item}</td><td><b>{money(o.amount)}</b></td><td><Status value={o.status}/></td></tr>)}</tbody></table></div>; }
function Quick({label,desc,icon:Icon,onClick}) { return <button className="quick-action" onClick={onClick}><span><Icon size={18}/></span><div><b>{label}</b><small>{desc}</small></div><ArrowUpRight size={16}/></button>; }

export default App;